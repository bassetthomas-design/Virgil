﻿using System.Windows;
namespace Virgil.App { public partial class App : Application {} }
